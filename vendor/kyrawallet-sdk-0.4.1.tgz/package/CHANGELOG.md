# Changelog

Every change to what a site sends or receives ships as a new version with a line here.

## 0.4.1 (2026-11-26)

No breaking change. The wallet now serves transactions and messages on every chain it connects; read
each chain's `scopes` from `connect`:

- **Xahau** (`xrpl:21337`, `xrpl:21338`): `signAndSubmit({ chain, tx })` signs a direct XAH
  `Payment` (`Amount` in drops) with the Xahau account and Xahau's NetworkID (the wallet sets it;
  don't send `NetworkID`). Issued amounts and other types on Xahau answer `UNSUPPORTED`.
- **XRPL EVM** (`eip155:1440000`, `eip155:1449000`), through `request({ method, chain, params })`
  with EIP-1193 params:
  - `eth_accounts`, `eth_chainId`;
  - `personal_sign` (`[message, address]`, text or 0x hex) and `eth_signTypedData_v4`
    (`[address, typedData]`; a domain `chainId` must be this chain's): resolve
    `{ account, publicKey, signature }`, a 65-byte `0x r‖s‖v` signature (ethers `verifyMessage` /
    `verifyTypedData`);
  - `eth_sendTransaction` (`[{ from?, to, value?, data?, gas? }]`): a native transfer, or a contract
    call the wallet estimates, prices and reviews (ERC-20 `transfer` / `approve` decoded, an unlimited
    approval flagged; any other call shown as raw data with a warning). The wallet sets nonce, fees and
    gas; a `nonce` is refused, fee hints are ignored, contract deployment is refused. Resolves
    `{ hash: "0x…", outcome }` like `signAndSubmit`.
- **TRON** (`tron:728126428`, Nile `tron:3448148188`):
  - `tron_signMessage` (`{ message }`): TronWeb `signMessageV2`, resolves
    `{ account, publicKey, signature }`;
  - `tron_sendTransaction` (`{ to, amount }`, amount in sun): a TRX transfer, resolves
    `{ hash: <txID>, outcome }`.
- Results of submitting methods (`xrpl_signAndSubmit`, `eth_sendTransaction`,
  `tron_sendTransaction`) carry the chain's own hash format; a lost answer is `unknown`, never resent.
- Method names may contain underscores after the namespace (`eth_signTypedData_v4`).

## 0.4.0 (2026-11-26)

- `connect` serves every chain the wallet keeps an account for, all or nothing:
  - Xahau (`xrpl:21337`, `xrpl:21338`): scope `xrpl_signMessage`, `xrpl_signIn`. Sign-in names the
    Xahau chain and is signed with the Xahau account's key. `signAndSubmit` there answers `UNSUPPORTED`.
  - XRPL EVM (`eip155:1440000`, `eip155:1449000`) and TRON (`tron:728126428`, `tron:3448148188`):
    the address and public key are shared and the scope is empty; every method there answers
    `UNSUPPORTED` ("not available yet"). The window says so before the user shares.
- New constants `XAHAU_MAINNET`, `XAHAU_TESTNET`, `XRPL_EVM_MAINNET`, `XRPL_EVM_TESTNET`,
  `TRON_MAINNET`, `TRON_NILE`.
- Read `scopes` from `connect` to offer only what the running wallet serves on each chain.
- Auth: verify `signMessage` over the returned `message` (the text the wallet wrote), never over the
  site's own message. For sign-in, use `signIn` (CAIP-122); the wallet refuses a message whose lines
  start with sign-in fields (`URI:`, `Nonce:`, …), so message-based auth formats do not apply.

## 0.3.0 (2026-11-25)

- New: `signMessage({ chain, message })` and `signIn({ chain, nonce, statement?, resources? })`
  (connector methods `xrpl_signMessage`, `xrpl_signIn`). Both resolve
  `{ account, chain, address, publicKey, message, signature }`: the exact text the wallet wrote and the
  user signed, and its Ed25519 signature. Sign-in is CAIP-122 as the XRPL Wallet Kit verifies it.
- `connect`'s scopes now list `xrpl_signMessage` and `xrpl_signIn` next to `xrpl_signAndSubmit`.

## 0.2.3 (2026-11-25)

- No API change. `connect` and `signAndSubmit` on the other XRP Ledger network than the user's
  wallet setting no longer fail: the wallet's window serves the network the request names, for that
  window only, and tells the user ("Mainnet for this site only"). A `connect` naming both `xrpl:0`
  and `xrpl:1` is still refused.

## 0.2.2 (2026-11-25)

- No API change. The wallet now signs a holder's `TrustSet` for sites: add a token line with the
  site's limit, change its limit, or remove it (`LimitAmount` value `"0"`, only with a zero balance).
  Freezes, authorization, enabling rippling and quality settings stay described and refused.

## 0.2.1 (2026-11-25)

- The channel identifier is `kyra-wallet` (was `web5-wallet`): pair with a wallet of the same build;
  an older wallet is ignored and the call ends `NOT_READY`.
- The caller's `AbortSignal` listener is removed once the window is ready or fails.
- The wallet now signs direct `Payment`s for sites (XRP or one issued token, optional
  `DestinationTag`), on the chain the site names.

## 0.2.0 (2026-11-25)

Breaking (connector protocol v2, ADR-0025): chains are CAIP-2 IDs and accounts CAIP-10 IDs.

- `connect(chains)` takes one CAIP-2 ID or an array (`"xrpl:1"`, was `"testnet"`) and resolves
  `{ accounts: [{ account: "xrpl:1:r…", chain, address, publicKey? }], scopes }`; `scopes` lists the
  methods the wallet serves per chain.
- `signAndSubmit({ chain, tx })` (was `{ network, tx }`); `chain` must be `xrpl:<id>`.
- `request({ method, chain?, params? })` (was `request(method, params)`); chain methods are named
  `<namespace>_<name>` and need their chain. `signTransaction` is gone (still refused by the wallet).
- `WRONG_NETWORK` is now `WRONG_CHAIN`. New exports: `XRPL_MAINNET`, `XRPL_TESTNET`, `KyraChainId`,
  `KyraSession`.

## 0.1.1 (2026-11-25)

- `walletOrigin` accepts plain `http` only for a wallet on this machine (`localhost`, `127.0.0.1`,
  `[::1]`); any other origin must be `https`.
- README: a page that opens Kyra must not send `Cross-Origin-Opener-Policy: same-origin`.

## 0.1.0 (2026-11-25)

- First local-testing release: `openKyra`, `connect`, `signAndSubmit`, `isKyraAvailable`,
  `KyraRequestError`.
