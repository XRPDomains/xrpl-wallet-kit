# @kyrawallet/sdk

Site SDK for [Kyra Wallet](https://kyrawallet.app), a passkey web wallet. A site opens the wallet's
`/connect` window from a click, connects accounts on the chains it names and asks the wallet to
review, sign and submit transactions. The wallet prepares the exact transaction itself (fee, sequence, expiry), shows
the user a full review with the site's verified origin, asks for the passkey, checks the ledger again
right before submitting, and answers with the hash and the validated outcome.

- One self-contained ES module, no runtime dependencies, standalone type declarations.
- Side-effect free import, safe during server rendering: only `openKyra()` touches `window`.
- No retries: a transaction handed to the wallet never becomes a failure without ledger evidence.
- Chains and accounts use the common identifiers: CAIP-2 chain IDs (`xrpl:0`, `xrpl:1`) and CAIP-10
  account IDs (`xrpl:1:r…`), the same ones WalletConnect and the XRPL Wallet Kit use. Every request
  says which chain it is for.

## Install

```sh
npm install @kyrawallet/sdk          # once published
npm install ./kyrawallet-sdk-0.4.1.tgz   # from a tarball for local testing
```

## Use

```ts
import { KyraRequestError, openKyra, XRPL_TESTNET } from "@kyrawallet/sdk";

button.addEventListener("click", async () => {
  // From a user gesture, or the browser blocks the window.
  const kyra = openKyra({ walletOrigin: "http://localhost:5173" }); // omit for the published wallet
  try {
    const { accounts, scopes } = await kyra.connect(XRPL_TESTNET); // "xrpl:1"
    const { address } = accounts[0]; // accounts[0].account is "xrpl:1:r…"
    // scopes["xrpl:1"].methods lists what the wallet does for this site there.

    const { hash, outcome, result } = await kyra.signAndSubmit({
      chain: XRPL_TESTNET,
      tx: { TransactionType: "TicketCreate", TicketCount: 1 },
    });
    if (outcome === "unknown") {
      // Look `hash` up on the ledger (when present). Never send the transaction again.
    }
  } catch (error) {
    if (error instanceof KyraRequestError && error.code === "USER_REJECTED") {
      // The user said no in the wallet.
    }
  } finally {
    kyra.close();
  }
});
```

A `KyraConnector` keeps its window: send further requests on the same object while the window is open.
Each new `openKyra()` reuses the named window (`kyra-wallet`), which reloads and asks for the passkey
again.

## API

### `openKyra(options?) → KyraConnector`

| Option | Default | |
|---|---|---|
| `walletOrigin` | `https://connect.kyrawallet.app` | A bare origin. Plain `http` only for a wallet on this machine (`localhost`, `127.0.0.1`, `[::1]`); the local Kyra wallet is `http://localhost:5173`. Throws `TypeError` otherwise. |
| `readyTimeoutMs` | `20000` | How long the window may take to say it is listening. |
| `requestTimeoutMs` | `600000` | How long one request waits for the user. Sent to the wallet as `expiresAt`: the wallet submits nothing after it. |
| `pollMs` | `500` | How often the SDK checks that the window is still open. |
| `scope` | `window` | The site window (tests). |

### Chains

| Chain | CAIP-2 ID | For sites today |
|---|---|---|
| XRP Ledger Mainnet | `xrpl:0` (`XRPL_MAINNET`) | yes |
| XRP Ledger Testnet | `xrpl:1` (`XRPL_TESTNET`) | yes |
| XRP Ledger Devnet | `xrpl:2` | no |
| Xahau Mainnet / Testnet | `xrpl:21337` / `xrpl:21338` (XLS-72d) | not yet |
| XRPL EVM Mainnet / Testnet | `eip155:1440000` / `eip155:1449000` | not yet |
| Tron Mainnet | `tron:728126428` (CASA decimal form) | not yet |

Do not hard-code the last column: `connect` answers, per chain, the methods the wallet serves this site
(`scopes`), and a chain it does not serve is refused with `UNSUPPORTED`. Chain methods are named
`<namespace>_<name>` (`xrpl_signAndSubmit`); EVM methods will keep their EIP-1193 names under `eip155`.

### `KyraConnector`

| Method | Resolves with |
|---|---|
| `ready()` | when the window is listening |
| `connect(chains, { signal }?)` | `{ accounts: [{ account, chain, address, publicKey? }], scopes: { [chain]: { methods } } }` for every requested chain (one ID or an array); a wallet answer on other chains rejects `WRONG_CHAIN` |
| `signAndSubmit({ chain, tx }, { signal }?)` | `{ hash?, outcome: "confirmed" \| "failed" \| "expired" \| "unknown", result? }`; `chain` is `xrpl:<id>` |
| `signMessage({ chain, message }, { signal }?)` | `{ account, chain, address, publicKey, message, signature }`: the text the wallet wrote and signed (below) |
| `signIn({ chain, nonce, statement?, resources? }, { signal }?)` | the same shape; CAIP-122 sign-in |
| `request({ method, chain?, params? }, { signal }?)` | the raw result: `connect` / `disconnect` without `chain`, any chain method with its `chain` |
| `close()` | closes the window (the wallet stores no per-site grant) |

`isKyraAvailable(scope?)` is a passive check (the page can open windows); it opens nothing.

### Transactions

`tx` states the intent: `TransactionType` and the type's fields, optionally `Account` (must be the
connected account). Do **not** autofill: a request carrying `Fee`, `Sequence`, `LastLedgerSequence`,
`SigningPubKey`, `TxnSignature`, `Signers`, `NetworkID` or `TicketSequence` is refused
(`INVALID_REQUEST`). The wallet sets them from one validated ledger snapshot.

Signed and submitted for sites today (XRP Ledger, Mainnet and Testnet):

| Type | Shape |
|---|---|
| `Payment` | direct only: `Destination` (another account), `Amount` (XRP drops as a string, or one issued amount `{ currency, issuer, value }` in canonical form), optional `DestinationTag`. No `Paths`, `SendMax`, `DeliverMin`, `Flags` (partial payments) or MPT amounts. Checked like the wallet's own Send (balance, reserve and fee; the recipient's tag requirement; trust lines, issuer flags and transfer fee), and again right before submitting. On the chain the site names, Mainnet included |
| `TrustSet` | a holder's line: `LimitAmount` `{ currency, issuer, value }` in canonical form, `value` a plain decimal above zero (add the line or change its limit) or `"0"` (remove it, only with a zero balance); `Flags` absent, 0 or tfSetNoRipple (the wallet keeps rippling off). Freezes, authorization, enabling rippling and `QualityIn`/`QualityOut` are described and refused. The review shows the line's current limit and balance and the reserve change; checked again right before submitting |
| `AccountSet` | one change: `SetFlag` or `ClearFlag` 1 (require destination tag), 3 (disallow XRP) or 9 (deposit authorization), or `Domain` (hex of a domain name, `""` to clear) |
| `TicketCreate` | `TicketCount` 1–10 |
| `OfferCancel` | `OfferSequence` of one of the account's offers |
| `CheckCancel` | `CheckID` of a check the account sent or receives |
| `NFTokenCancelOffer` | `NFTokenOffers`: 1–20 of the account's own offers |
| `NFTokenBurn` | `NFTokenID` the account holds (no `Owner`) |
| `NFTokenAcceptOffer` | exactly one of `NFTokenSellOffer` / `NFTokenBuyOffer` (no broker) |

Anything else the wallet recognizes is shown to the user with the reason and refused
(`UNSUPPORTED`); nothing is signed blind. Signed bytes are not returned to sites (no sign-only
method).

### Messages and sign-in

The wallet never signs bytes a site supplies. It writes the whole text itself: the first line names
your page's host (the origin the browser reports, not a value you send), then the account, then your
content, then fields only the wallet writes. The user sees that exact text before the passkey. The
signature is Ed25519 over the text's UTF-8 bytes with `publicKey` (`ED…`); `address` is that key's
classic address. Nothing is sent to the ledger and nothing is paid.

`signMessage({ chain, message })`: `message` is 1 to 1024 characters of text. Line feeds and tabs are
allowed; other control characters, and lines starting with a field name (`URI:`, `Chain ID:`,
`Issued At:`, …), are refused (`INVALID_REQUEST`). The signed text:

```text
<site host> wants you to sign a message with your XRPL account:
<r-address>

<message>

URI: <site origin>
Chain ID: xrpl:1
Issued At: <wallet time, ISO 8601>
```

`signIn({ chain, nonce, statement?, resources? })` follows CAIP-122, line for line as the XRPL Wallet
Kit's `assertSignInContext` and `verifyWalletSignIn` check it. `nonce` is 8 to 128 printable
characters without spaces; your server issues it and consumes it once. `statement` is one line, up to
512 characters. `resources` holds up to 16 URIs. The signed text:

```text
<site host> wants you to sign in with your XRPL account:
<r-address>

<statement>                      (only when given)

URI: <site origin>
Version: 1
Chain ID: xrpl:1
Nonce: <nonce>
Issued At: <wallet time, ISO 8601>
Resources:                       (only when given)
- <uri>
```

Verify on your server, never in the page: the signature over `message` with `publicKey`, that the key's
address is the account, the host, URI, chain, nonce and Issued At you expect, then consume the nonce.

### Outcomes and errors

| Situation | Result |
|---|---|
| Validated, `tesSUCCESS` | `{ hash, outcome: "confirmed" }` |
| Validated, another code | `{ hash, outcome: "failed", result }` |
| Expired without inclusion | `{ hash, outcome: "expired" }` |
| Handed to the wallet, then the window closed, the answer was lost, timed out, or was aborted | `{ outcome: "unknown", hash? }`: look it up, never resend |
| The ledger changed between review and submission | the user sees it in the wallet and may review again or reject |

`KyraRequestError.code`: `USER_REJECTED`, `UNAUTHORIZED` (another account), `UNSUPPORTED` (a chain
the wallet does not serve or is not on, a method or type not offered), `INVALID_REQUEST` (malformed,
a chain that is not CAIP-2 or a method of another namespace, wallet-owned fields, expired, a second
request while one is open), `INTERNAL`, `WINDOW_CLOSED`, `POPUP_BLOCKED`, `NOT_READY` (wrong
`walletOrigin`, failed load, or a host that cut the window's link), `TIMEOUT`, `ABORTED`,
`WRONG_CHAIN`, `BAD_RESPONSE`. The last six come from the SDK, before anything was handed off.

## Security notes

- Answers are accepted only from the window the SDK opened and from `walletOrigin`, and validated
  against the protocol before use.
- The wallet identifies the site by its browser-verified origin only.
- The wallet's `/connect` route is served without `Cross-Origin-Opener-Policy` so the window keeps its
  link to the site; every other wallet route stays isolated.
- Your page must not send `Cross-Origin-Opener-Policy: same-origin` either: it cuts the window off
  and every request ends `NOT_READY`. Use `same-origin-allow-popups` (or none) on pages that open
  Kyra.
